function printPage() {
    window.print();
  }
  